class GiostraDAO:
    def __init__(self, nome, capienza, durata, limite_eta, limite_altezza, descrizione, stato_funzionamento, numero_persone):
        self.nome = nome
        self.capienza = capienza
        self.durata = durata
        self.limite_eta = limite_eta
        self.limite_altezza = limite_altezza
        self.descrizione = descrizione
        self.stato_funzionamento = stato_funzionamento
        self.numero_persone = numero_persone
        
