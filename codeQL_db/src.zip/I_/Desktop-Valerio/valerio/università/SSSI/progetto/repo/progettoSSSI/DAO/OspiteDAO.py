class OspiteDAO:

    def __init__(self,nome, eta, altezza):
        self.nome = nome 
        self.eta = eta
        self.altezza = altezza
       
        
