class ClienteDAO:



    def __init__(self,nickname, email, password, eta, altezza, biglietto):
        self.nickname = nickname 
        self.email = email
        self.password = password
        self.eta = eta
        self.altezza = altezza
        self.biglietto = biglietto 
        
        
