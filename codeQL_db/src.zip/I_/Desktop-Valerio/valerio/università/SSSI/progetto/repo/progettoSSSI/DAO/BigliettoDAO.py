class BigliettoDAO:

    def __init__(self,codice, data, ospiti):
        self.codice = codice 
        self.data = data
        self.ospiti = ospiti
  
        
