class PrenotazioneDAO:

    def __init__(self,fascia_oraria,numero_ospiti,nome_giostra,nome_cliente):
        self.fascia_oraria = fascia_oraria
        self.numero_ospiti = numero_ospiti
        self.nome_giostra = nome_giostra
        self.nome_cliente = nome_cliente
        
